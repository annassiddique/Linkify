package com.nyx.lindkedIn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LindkedInApplicationTests {

	@Test
	void contextLoads() {
	}

}
