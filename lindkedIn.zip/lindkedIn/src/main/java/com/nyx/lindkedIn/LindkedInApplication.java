package com.nyx.lindkedIn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LindkedInApplication {

	public static void main(String[] args) {
		SpringApplication.run(LindkedInApplication.class, args);
	}

}
